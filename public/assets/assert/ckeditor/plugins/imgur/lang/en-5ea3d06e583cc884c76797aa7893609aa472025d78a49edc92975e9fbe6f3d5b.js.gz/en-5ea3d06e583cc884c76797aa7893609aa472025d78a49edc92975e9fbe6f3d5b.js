CKEDITOR.plugins.setLang('imgur', 'en', {
    clientIDMissing: 'Add config.imgurClientID to your assets/javascripts/ckeditor/config.js',
    uploading: ' images are uploading...',
    failToUpload: 'Failed to upload:',
    label: 'upload images'
});
